package com.bigkoo.convenientbanner.listener;

/**
 * Created by Sai on 15/11/13.
 */
public interface OnItemClickListener {
    public void onItemClick(int position);
}
